import com.example.models.Account;

public class Savings extends Account {

	public Savings(double initialDeposit) {
		// TODO Auto-generated constructor stub
	}


}
