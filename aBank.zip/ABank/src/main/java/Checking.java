import com.example.models.Account;

public class Checking extends Account {

	public Checking(double initialDeposit) {
		// TODO Auto-generated constructor stub
	}



}
