package com.example.logging;

import org.apache.log4j.Logger;

public class Logging {
	
	public final static Logger logger = Logger.getLogger(Logging.class);
	
}
